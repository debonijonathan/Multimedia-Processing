#include "../JuceLibraryCode/JuceHeader.h"
#include <cassert>


/******************************************************************************
* Filter class
******************************************************************************/
template <typename SampleType>
class MyFilter {
public:
	MyFilter(int lowFrequency, int highFrequency, double sampleRate)
		: filterLowPass(dsp::IIR::Coefficients<SampleType>::makeLowPass(sampleRate, highFrequency))
		, filterHighPass(dsp::IIR::Coefficients<SampleType>::makeHighPass(sampleRate, lowFrequency))
	{
		assert(lowFrequency < highFrequency);
		assert((int)sampleRate > (highFrequency / 2)); // Nyquist
		dsp::ProcessSpec spec{ sampleRate, 8192, 1 };
		filterLowPass.prepare(spec);
		filterHighPass.prepare(spec);
	}

	~MyFilter() { /* Intentionally empty */ }

	void process(SampleType *block, size_t blockSize) {
		SampleType *cc[1] = { block };
		SampleType* const* channels = cc;

		dsp::AudioBlock<SampleType> audioblock(channels, 1, blockSize);

		dsp::ProcessContextReplacing<SampleType> context(audioblock);
		filterLowPass.process(context);
		filterHighPass.process(context);
	}

private:
	dsp::IIR::Filter<SampleType> filterLowPass;
	dsp::IIR::Filter<SampleType> filterHighPass;
};


#ifndef DEBUG_toString
#define DEBUG_toString(var)  " " << #var << "=" << var
#endif

/******************************************************************************
* CircularBuffer class
*
*
******************************************************************************/
template <typename Type>
class CircularBuffer
{
public:
	CircularBuffer(const int size, const int numSamples)
		: bufferSize(size)
		, bufferStep(numSamples)
		, bufferIndex(0)
	{
		assert(size > 0);
		assert(numSamples > 0);
		assert(numSamples < size);

		buffer = new Type[size];
		std::memset(buffer, 0, size * sizeof(Type));

		std::cout << "CircularBuffer("
			<< DEBUG_toString(bufferSize)
			<< ", " << DEBUG_toString(numSamples)
			<< ")" << std::endl;
	}

	~CircularBuffer() {
		delete[] buffer;
	}

	/**
	* return true if CircularBuffer has 'numSamples' new samples
	*/
	bool process(Type sample) {
		buffer[bufferIndex++] = sample;
		if (bufferIndex >= bufferSize)
			bufferIndex = 0;
		return (bufferIndex % bufferStep) == 0;
	}

	/**
	* copy CircularBuffer to outputBuffer starting from the oldest values
	*/
	void copyData(Type * const outputBuffer) {
		assert(outputBuffer != nullptr);

		if (bufferIndex == 0)
			std::memcpy(outputBuffer, buffer, bufferSize * sizeof(Type));
		else {
			const size_t firstPartSize = bufferSize - bufferIndex;
			const size_t secondPartSize = bufferIndex;
			std::memcpy(outputBuffer, buffer + bufferIndex, firstPartSize * sizeof(Type));
			std::memcpy(outputBuffer + firstPartSize, buffer, secondPartSize * sizeof(Type));
		}
	}

private:
	Type *buffer;
	size_t bufferIndex;
	const size_t bufferSize;
	const size_t bufferStep;
};
/******************************************************************************
* Tone class
*
*
******************************************************************************/
class Tone {
private:
	char character;
	int low;
	int high;
	char *string;
	int occurency;
public:
	Tone(char ch, int down, int up, char *text) : character{ ch }, low{ down }, high{ up }, string{ text }{
		occurency = 0;
	}

	char decode(int num) {
		return string[num-1];
	}

	char getChar() {
		return character;
	}

	bool lookup(float fftBuffer[], int fftSize, float time) {

		if ((fftBuffer[low - 1] >= -26 || fftBuffer[low] >= -26 || fftBuffer[low + 1] >= -26) && (fftBuffer[high - 1] >= -26 || fftBuffer[high] >= -26 || fftBuffer[high + 1] >= -26)) {
			return true;
		}
		return false;
	}
};

/******************************************************************************
* Main class
*
*
******************************************************************************/


int main(int argc, char **argv)
{
	if (argc != 2) {
		std::cerr << "Missing input audio file to analyze." << std::endl;
		return 1;
    }

    File input = File::getCurrentWorkingDirectory().getChildFile(argv[1]);
    if (input.exists() == false) {
		std::cerr << "File doesn't exists." << std::endl;
		return 1;
	}

	AudioFormatManager fmgr;
	fmgr.registerBasicFormats();
	ScopedPointer<AudioFormatReaderSource> source = new AudioFormatReaderSource(fmgr.createReaderFor(input), true);

	unsigned int numChannels = source->getAudioFormatReader()->numChannels;
	double sampleRate = source->getAudioFormatReader()->sampleRate;

	AudioBuffer<float> myBuffer(numChannels, sampleRate / 10);
	AudioSourceChannelInfo info(myBuffer);

	source->prepareToPlay(512, sampleRate);
	/*Istanziamo la FFT*/
	int order = 9;
	const int fftSize = pow(2, order);
	float buffer[512 * 2];
	dsp::FFT fft { order };
	/*Creiamo il circularBuffer e il filtro*/
	CircularBuffer<float> circularBuffer {fftSize, 128 };
	MyFilter<float> filter { 690, 1650, sampleRate};

	/*Impostiamo i Toni per capire che tasto �*/
	Tone t1{ '1', 45, 75, "" };
	Tone t2{ '2', 45, 85, "ABC" };
	Tone t3{ '3', 45, 95, "DEF" };
	Tone t4{ '4', 50, 75, "GHI" };
	Tone t5{ '5', 50, 85, "JKL" };
	Tone t6{ '6', 50, 95, "MNO" };
	Tone t7{ '7', 55, 75, "PQRS" };
	Tone t8{ '8', 55, 85, "TUV" };
	Tone t9{ '9', 55, 95, "WXYZ" };
	Tone ta{ '*', 60, 75, "+" };
	Tone t0{ '0', 60, 85, " " };
	Tone th{ '#', 60, 95, "^" };
	Tone tones[] = { t1, t2, t3, t4, t5, t6, t7, t8, t9, ta, t0, th };

	//Impostiamo il tempo per ogni tasto
	float time;
	float last_time;
	//Impostiamo i caratteri del testo e il messaggio
	char character = NULL;
	char last_character = NULL;
	int textMessage[20][2];
	int pos_textmess = 0;
	//Impostiamo i toni e le occorrenze trovate
	int tone;
	int occurrency = 0;
	bool insert = false;
	int total_sample_nr = 0;
     
	while (source->getNextReadPosition() < source->getTotalLength())
	{
		// Read next audio block
		source->getNextAudioBlock(info);

		const int numSamples = info.buffer->getNumSamples();
		const int numChannels = info.buffer->getNumChannels();
		const float **data = info.buffer->getArrayOfReadPointers();

		// loop through each channel
		for (int channel = 0; channel < numChannels; channel++)
		{
			// channelData contains now 'numSamples' of input data
			const float *channelData = data[channel];

			//TODO implement you algorithm! The following example dumps to stdout the audio contents
			for (int sampleIndex = 0; sampleIndex < numSamples; sampleIndex++) {
				total_sample_nr++;
				/*Processiamo il dato nel circularBuffer
				*
				* In questo modo si possono
				* inserire nel buffer circolare meno campioni alla volta e far generare pi� spesso la FFT.
				*/
				if (circularBuffer.process(channelData[sampleIndex])) {
					//calcoliamo il tempo passato
					time = (float)(total_sample_nr) / sampleRate;

					//Copiamo il buffer della fft dentro al circularBuffer
					circularBuffer.copyData(buffer);
					//Filtriamo i dati per rimuovere il rumore
					filter.process(buffer, fftSize);
					//Otteniamo lo spettro grazie al buffer tramite fft
					fft.performFrequencyOnlyForwardTransform(buffer);
					//otteniamo i decibel
					buffer[0] = 20.0f * log10f(buffer[0] / (float)fftSize / 2.0f);
					for (int i = 1; i < fftSize / 2; i++) {
						buffer[i] = 20.0f * log10f((2.0f * buffer[i]) / (float)fftSize / 2.0f);
					}

					//Passiamo tutto l'array di toni per scoprire quali sono
					for (int i = 0; i < 12; i++) {
						if (tones[i].lookup(buffer, fftSize, time)) {
							character = tones[i].getChar();
							tone = i;
							last_time = time;
							insert = false;
						}
						else {
							//Se i toni sono uguali aumento l'occorrenza e imposto il messaggio
							if (character != NULL && i == tone) {
								occurrency++;
								last_character = character;
								character = NULL;
							}
						}
					}
					/*
						Controlliamo se non � stato inserito
						il valore entro 1 secondo in modo da definire la parola
					*/
					float val = (time - last_time);
					//std::cout << val << std::endl;
					if (val > 1 && !insert) {
						textMessage[pos_textmess][0] = (int) last_character;
						textMessage[pos_textmess][1] = occurrency;
						occurrency = 0;
						pos_textmess++;
						insert = true;

					}

				}
			}
		}
	}


	std::cout << "Numeri Composti" << std::endl;
	//Stampiamo i numeri trovati 
	for (int i = 1; i < pos_textmess; i++) {
		std::cout << (char)textMessage[i][0] << "\t";
	}
	std::cout << std::endl;
	
	std::cout << "Messaggio Composto" << std::endl;
	//Stampiamo i caratteri trovati 
	for (int i =1; i < pos_textmess;i++) {
		for (int j = 0; j < 12; j++) {
			if (tones[j].getChar() == (char)textMessage[i][0]) {
				int val = textMessage[i][1];
				std::cout << tones[j].decode(val) << "\t";
			}
		}
	}
	std::cout << std::endl;


	return 0;
}
